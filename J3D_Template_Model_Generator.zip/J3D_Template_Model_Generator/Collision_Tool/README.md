# pyKCLCreate
Tool to create Super Mario Galaxy 1/2 compatible KCL files. 
Originally written by blank63, updated to work with Python 3 and PyQt5 by froggo.

Requires PyQt5.

`pip install pyqt5`
